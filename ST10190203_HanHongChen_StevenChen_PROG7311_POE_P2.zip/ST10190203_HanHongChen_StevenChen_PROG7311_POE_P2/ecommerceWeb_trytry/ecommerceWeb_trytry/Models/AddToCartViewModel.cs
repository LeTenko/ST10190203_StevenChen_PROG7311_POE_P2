﻿namespace ecommerceWeb_trytry.Models
{
    public class AddToCartViewModel
    {
        public int ProductId { get; set; }
        public int Quantity { get; set; }


    }
}
