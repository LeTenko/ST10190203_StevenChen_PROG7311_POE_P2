﻿using Microsoft.AspNetCore.Identity;

namespace ecommerceWeb_trytry_trail2.Areas.Identity.Data
{
    public class Try_User: IdentityUser
    {

        public string? A_FullName { get; set; }


    }
}
